import Link from "next/link";
import { useState } from "react";





export default function ProductPage({products, page,totalPages}) {
const [query, setQuery] = useState("");


    return (
        <div className="p-8">
            <h1 className="text-2xl font-bold mb-6">Page {page}</h1>

            <input type="text" placeholder="Search by products" value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full px-4 border  rounded mb-6"
            />

            <div className="space-y-4">
                {products
                    .filter((product) =>
                    product.title.toLowerCase().includes(query.toLowerCase())
                    )
                    .map((product) => (
                    <div key={product.id} className="border p-4 rounded shadow">
                        <img
                        src={product.image}
                        alt={product.title}
                        className="h-40 w-full object-contain mb-2"
                        />
                        <h2 className="text-lg font-semibold">{product.title}</h2>
                        <Link href={`/products/${product.id}`}>
                        <button className="mt-2 px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">
                            View Details
                        </button>
                        </Link>
                    </div>
                    ))}
                </div>

            <div className="flex justify-between mt-8">
                {page > 1 ? (
                    <Link href={`/page/${parseInt(page) - 1}`}>
                        <button className="px-4 py-2 bg-blue-400 rounded hover:bg-indigo-500">Previous</button>
                    </Link >
                ) : <div /> }{/* */}

                {page < totalPages && (
                <Link href={`/page/${parseInt(page) + 1}`}>
                <button className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-indigo-500">Next</button>
                </Link>
                )}     
            </div>
        </div>
    );
}

export async function getStaticPaths() {

    const totalPages = Math.ceil(20 / 5);

    const paths = Array.from({length: totalPages}, (_,i) => ({
        params: {page: `${i+1}`},
    }));
    
    return {
        paths,
        fallback: false,
    };
}

export async function getStaticProps({params}) {
    const page = parseInt(params.page);
    const limit = 5;
    const skip = (page - 1) * limit;
    const res = await fetch ('https://fakestoreapi.com/products');
    const allProducts = await res.json();
    console.log(allProducts);
    const paginated = allProducts.slice(skip,skip + limit);

    const totalPages = Math.ceil(allProducts.length / limit);

    return {
        props: {
            products: paginated,
            page,
            totalPages,
        },
    };
}