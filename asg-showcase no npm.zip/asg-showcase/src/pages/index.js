import Link from "next/link";
// import { useState, useEffect } from "react";

// export default function Home ({products}) {
//   return (
//     <div className="p-8">
//       <h1 className="text-2xl font-bold mb-4 text-center">Product Showcase</h1>
//       {/* Product list will go here */}

//     <div className="space-y-4">
      
//     {products.map((product) => (
//       <div key={product.id} className="border p-4 rounded shadow flex items-center gap-4">
//         <img
//         src={product.image}
//         alt={product.title}
//         className="h-24 w-24 object-contain"
//         />
//         <h2 className="font-semibold text-lg mb-2">{product.title}</h2>
//         <Link href={`/products/${product.id}`}>
//         <button className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">View Details

//         </button>
//         </Link>
//         </div>
//     ))}
//         </div>
//       </div>
    
//   );
// }

// export async function getStaticProps() {
//   const res = await fetch('https://fakestoreapi.com/products?limit=5')
//   const data = await res.json();
//   console.log(data);
//   return {
//     props: {
//       products: data,
//     },
//   };
// }

export default function Home() {
  return null;
}

export async function getStaticProps() {
  return {
    redirect: {
      destination: '/page/1',
      permanent: false,
    },
  };
}

