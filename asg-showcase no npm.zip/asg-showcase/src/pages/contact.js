export default function ContactPage() {
    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Contact here</h1>
            <p>If you need to contact me, You can email me at owenmahaputra10@gmail.com</p>
        </div>
    );
}