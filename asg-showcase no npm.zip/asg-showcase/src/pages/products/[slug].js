import { useRouter } from "next/router"

export default function ProductDetail({product}) {
    const router = useRouter();

    if(router.isFallback) {
        return <div>Loading...</div>
    }

    return (
        <div className="p-8 max-w-xl mx-auto">
            <h1>{product.title}</h1>
            <img src={product.image} alt={product.title}/>
            <p>{product.description}</p>
            <p>${product.price}</p>
        </div>
    );
}

export async function getStaticProps({params}) {
    const res = await fetch(`https://fakestoreapi.com/products/${params.slug}`);
    
    if(!res.ok) {
        return{
            notFound:true,
        }
    }

    const product = await res.json();

    return {
        props: {product},
    };
}

export async function getStaticPaths() {
    const res = await fetch("https://fakestoreapi.com/products");
    const product = await res.json();

    const paths = product.map((product) => ({
        params: {slug: product.id.toString()},
    }));

    return {
        paths,
        fallback: true,
    };
}

