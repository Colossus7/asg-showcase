import Link from "next/link";

export default function Layout({children}){
    return (
        <div>
            <nav className="bg-emerald-500 text-black px-6 py-4 flex gap-6">
                <Link href="/" className="hover:underline">Home</Link>
                <Link href= "/contact" className="hover:underline">Contact</Link>
            </nav>
            <main className="p-6">{children}</main>
        </div>
    );
}